//
//  IGameTopupListener.h
//  GinSDK
//
//  Created by ITC on 17/7/25.
//

// TOPUP FEATURE REMOVED - IGameTopupListener Protocol
/*
#pragma mark - IGameTopupListener Protocol
@protocol IGameTopupListener <NSObject>
@required
- (void)onTopupFinish;
- (void)onTopupError:(NSString *)error;
@end
*/
