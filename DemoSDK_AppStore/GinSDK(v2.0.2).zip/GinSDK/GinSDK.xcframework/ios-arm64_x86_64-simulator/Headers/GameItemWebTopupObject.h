//
//  GameItemWebTopupObject.h
//  GinSDK
//
//  Created by ITC on 17/7/25.
//

// TOPUP FEATURE REMOVED - GameItemWebTopupObject class
/*
#import <Foundation/Foundation.h>

@interface GameItemWebTopupObject : NSObject

// Required properties
@property (nonatomic, strong) NSString *characterID;
@property (nonatomic, strong) NSString *characterName;
@property (nonatomic, strong) NSString *serverID;
@property (nonatomic, strong) NSString *productID;
@property (nonatomic, strong) NSString *amount;

// Optional properties
@property (nonatomic, strong) NSString *productName;
@property (nonatomic, strong) NSString *currencyUnit;
@property (nonatomic, strong) NSString *extraInfo;
@property (nonatomic, strong) NSString *refID;

// Convenience initializers
- (instancetype)initWithCharacterID:(NSString *)characterID
                           serverID:(NSString *)serverID
                          productID:(NSString *)productID
                             amount:(NSString *)amount;

- (instancetype)initWithCharacterID:(NSString *)characterID
                      characterName:(NSString *)characterName
                           serverID:(NSString *)serverID
                          productID:(NSString *)productID
                        productName:(NSString *)productName
                       currencyUnit:(NSString *)currencyUnit
                             amount:(NSString *)amount
                          extraInfo:(NSString *)extraInfo
                              refID:(NSString *)refID;

// Validation methods
- (BOOL)isValid;
- (NSString *)getValidationErrors;

// Utility methods
- (NSDictionary *)toDictionary;
- (NSString *)toJSONString;

@end
*/
